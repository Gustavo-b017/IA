from 11_combined_features_by_z_plus_surface import main
if __name__=="__main__":
    # Even tighter zoom and different camera
    main(out="combined_features_by_z_plus_surface_zoomed2.gif", pad=0.15, elev=40, azim=-30)
